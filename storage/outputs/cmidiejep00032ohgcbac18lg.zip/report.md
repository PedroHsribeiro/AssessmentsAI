# Questionnaire Analysis Report

## Q: Error processing

**A:** AI Analysis failed with gemini. Error: Cannot find module '@google/generative-ai'. Please check your API key and model name.

*Source:* System

---

